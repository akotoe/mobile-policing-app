package com.mobile.policing;

public class Message{
	private String id="";
	private String name="";
	private String location="";
	private String abuseType ="";
	private String description="";
	
	public String content="";
	
	
	/*Getters*/
	public String getID(){
		return this.id;
	}
	public String getName(){
		return this.name;
	}
	public String getLocation(){
		return this.location;
	}
	public String getAbuseType(){
		return this.abuseType;
	}
	public String getDescription(){
		return this.description;
	}
	/*Setters*/
	public void setID(String id){
		this.id=id;
	}
	public void setName(String name){
		this.name=name;
	}
	public void setLocation(String location){
		this.location=location;
	}
	public void setAbuseType(String abuseType){
		this.abuseType=abuseType;
	}
	public void setDescription(String description){
		this.description=description;
	}
	
	
}