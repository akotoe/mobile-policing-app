package com.mobile.policing;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;


public class ConfirmationActivity extends Activity{
	
	

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		Intent i = getIntent();
		i.getExtras();	
		
		try{
		TextView name = (TextView) findViewById(R.id.textViewMessage);
		name.setText("Hello");
        
		}catch (NullPointerException e){
			
		}
		setContentView(R.layout.confirmation);
             
    }	
	
	/*Close application*/
    public void close(View button) {
    	 System.exit(RESULT_OK);    
    }
}