package com.mobile.policing;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;


import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;

import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;

import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;


import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;




public class MainActivity extends Activity implements LocationListener{
	private JSONObject jsonObject = new JSONObject();
	Calendar c = Calendar.getInstance();
    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    String timeNow = df.format(c.getTime()); 
    private String currentLocation="Location Unknown";
    private LocationManager locationManager;
	private String provider;

	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        setContentView(R.layout.activity_main_form);
     
       
    	
        // Get the location manager    
    	locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
    	// Define the criteria how to select the locatioin provider -> use
    	// default
    	Criteria criteria = new Criteria();
    	provider = locationManager.getBestProvider(criteria, false);
    	Location location = locationManager.getLastKnownLocation(provider);

    	// Initialize the location fields
    	if (location != null) {
    		System.out.println("Provider " + provider + " has been selected.");
    		onLocationChanged(location);
    	} else {
    		
    		currentLocation="Location not available"; 
    	}
        
    }

    
    /*Handle form submit*/
    public void processForm(View button) throws ClientProtocolException, IOException {
          
    	Message message = new Message();
    	
    	final EditText idField =(EditText)findViewById(R.id.editTextId);
    	message.setID(idField.getText().toString());
    	
    	final EditText nameField =(EditText)findViewById(R.id.editTextName);
    	message.setName(nameField.getText().toString());	
    	
    	final Spinner abuseType =(Spinner)findViewById(R.id.spinnerabusetype);
    	message.setAbuseType(abuseType.getSelectedItem().toString());
    	
    	   	
    	final EditText descriptionField =(EditText)findViewById(R.id.editTextDescription);
    	message.setDescription(descriptionField.getText().toString());
    		
    	
    	try {
			jsonObject.put("id", message.getID());
			jsonObject.put("name", message.getName());
			jsonObject.put("nature", message.getAbuseType());
			jsonObject.put("time", timeNow);
			jsonObject.put("location", currentLocation);
			jsonObject.put("description", message.getDescription());
			
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		/*POST the JSON object*/
		
		try {
			DefaultHttpClient httpclient = new DefaultHttpClient();
			HttpPost httpPostRequest = new HttpPost("http://mobile-policing.herokuapp.com/issues/");

			StringEntity se;
			se = new StringEntity(jsonObject.toString());

			// Set HTTP parameters
			httpPostRequest.setEntity(se);
			httpPostRequest.setHeader("Accept", "application/json");
			httpPostRequest.setHeader("Content-type", "application/json");
			

			//long t = System.currentTimeMillis();
			HttpResponse response = (HttpResponse) httpclient.execute(httpPostRequest);
			
			Intent intent = new Intent(this, ConfirmationActivity.class);
	        
	 
	        //Add the message to the intent.
	        intent.putExtra("message", response.toString());
	 
	        //start the DisplayActivity
	        startActivity(intent);

	
		}
		catch (Exception e)
		{
			// More about HTTP exception handling in another tutorial.
			// For now we just print the stack trace.
			e.printStackTrace();
		}	       
       
    }
    
    /*Close application*/
    public void close(View button) {
    	 setContentView(R.layout.activity_main_form);
    	 System.exit(RESULT_OK);
    } 
    
    /* Request updates at startup */
	@Override
	protected void onResume() {
		super.onResume();
		locationManager.requestLocationUpdates(provider, 400, 1, this);
	}

	/* Remove the locationlistener updates when Activity is paused */
	@Override
	protected void onPause() {
		super.onPause();
		locationManager.removeUpdates(this);
	}

	@Override
	public void onLocationChanged(Location location) {
		float lat = (float) (location.getLatitude());
		float lng = (float) (location.getLongitude());
		
		currentLocation = "Lat:"+String.valueOf(lat)+"/Long:"+String.valueOf(lng);
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onProviderEnabled(String provider) {
		Toast.makeText(this, "Enabled new provider " + provider,
				Toast.LENGTH_SHORT).show();

	}

	@Override
	public void onProviderDisabled(String provider) {
		Toast.makeText(this, "Disabled provider " + provider,
				Toast.LENGTH_SHORT).show();
	}
    
       
}

